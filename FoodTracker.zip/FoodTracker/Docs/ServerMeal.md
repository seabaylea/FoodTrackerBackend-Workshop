

[**Back to README**](./README.md)
# ServerMeal {#top} 
### Examples
```swift
// Maps JSON string to Swift Object
let jsonString = ""
let serverMeal: ServerMeal? = ServerMeal(JSONString: jsonString)
```
###
```swift
// Maps JSON string to array of ServerMeal
let jsonString = ""
let serverMealArray: [ServerMeal]? = Mapper<ServerMeal>().mapArray(JSONString: jsonString)
```
###
```swift
// Maps JSON String to Dictionary mapping String to ServerMeal
let jsonString = ""
let Dictionary: [String: ServerMeal]? = Mapper<ServerMeal>().mapDictionary(JSONString: jsonString)
```
###
```swift
// Converts Swift Object to JSON string
let json: [String: Any] = [:]
let serverMeal = ServerMeal(JSON: json)
let jsonString: String? = serverMeal?.toJSONString(prettyPrint: true)
```

### Fields 
 - [**id**](#id)
 - [**name**](#name)
 - [**photo**](#photo)
 - [**rating**](#rating)

---


#### id   {#id}

```swift
var id: String?
```


---


#### name   {#name}

```swift
var name: String?
```


---


#### photo   {#photo}

```swift
var photo: String?
```


---


#### rating   {#rating}

```swift
var rating: Double?
```


---


[**Back to Top**](#top)


