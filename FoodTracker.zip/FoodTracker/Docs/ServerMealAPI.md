[**Back to README**](./README.md)
# ServerMealAPI {#top}

### Methods
 * [**serverMealCreate**](#serverMealCreate)
 * [**serverMealDelete**](#serverMealDelete)
 * [**serverMealDeleteAll**](#serverMealDeleteAll)
 * [**serverMealFindAll**](#serverMealFindAll)
 * [**serverMealFindOne**](#serverMealFindOne)
 * [**serverMealReplace**](#serverMealReplace)
 * [**serverMealUpdate**](#serverMealUpdate)


### **serverMealCreate**  {#serverMealCreate}
---
```swift
public static func serverMealCreate(data: ServerMeal? = nil, completionHandler: @escaping (_ returnedData: ServerMeal?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Create a new instance of the model and persist it

#### Parameters

- **data**  (optional) Model instance data
    - see [**ServerMeal**](ServerMeal.md)
- **completionHandler** (required)
    - closure takes as arguments `ServerMeal?`, `Response?` and  `Error?`

#### Response
[`ServerMeal`](ServerMeal.md)

### Authentication

No authentication required


### Example

```swift

let data: ServerMeal = ServerMeal() // Model instance data

ServerMealAPI.serverMealCreate(data: data) { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealCreate() finished with status code: \(status)")
    }
}
```


### **serverMealDelete**  {#serverMealDelete}
---
```swift
public static func serverMealDelete(id: String, completionHandler: @escaping (_ returnedData: Any?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Delete a model instance by {{id}}

#### Parameters

- **id**  (required) Model id
- **completionHandler** (required)
    - closure takes as arguments `Any?`, `Response?` and  `Error?`

#### Response
`Any`

### Authentication

No authentication required


### Example

```swift

let id: String = "id_example" // Model id

ServerMealAPI.serverMealDelete(id: id) { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealDelete() finished with status code: \(status)")
    }
}
```


### **serverMealDeleteAll**  {#serverMealDeleteAll}
---
```swift
public static func serverMealDeleteAll(completionHandler: @escaping (_ response: Response?, _ error: Error?) -> Void) -> Void
```

>Delete all instances of the model

#### Parameters

- **completionHandler** (required)
    - closure takes as arguments`Response?` and  `Error?`


### Authentication

No authentication required


### Example

```swift


ServerMealAPI.serverMealDeleteAll() { (response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let status = response?.statusCode {
        switch status {
        case 200:
            print("Request was successful")
        default:
            print("Response: \(response?.responseText)")
        }
    }
}
```


### **serverMealFindAll**  {#serverMealFindAll}
---
```swift
public static func serverMealFindAll(completionHandler: @escaping (_ returnedData: [ServerMeal]?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Find all instances of the model

#### Parameters

- **completionHandler** (required)
    - closure takes as arguments `[ServerMeal]?`, `Response?` and  `Error?`

#### Response
[`[ServerMeal]`](ServerMeal.md)

### Authentication

No authentication required


### Example

```swift


ServerMealAPI.serverMealFindAll() { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealFindAll() finished with status code: \(status)")
    }
}
```


### **serverMealFindOne**  {#serverMealFindOne}
---
```swift
public static func serverMealFindOne(id: String, completionHandler: @escaping (_ returnedData: ServerMeal?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Find a model instance by {{id}}

#### Parameters

- **id**  (required) Model id
- **completionHandler** (required)
    - closure takes as arguments `ServerMeal?`, `Response?` and  `Error?`

#### Response
[`ServerMeal`](ServerMeal.md)

### Authentication

No authentication required


### Example

```swift

let id: String = "id_example" // Model id

ServerMealAPI.serverMealFindOne(id: id) { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealFindOne() finished with status code: \(status)")
    }
}
```


### **serverMealReplace**  {#serverMealReplace}
---
```swift
public static func serverMealReplace(id: String, data: ServerMeal? = nil, completionHandler: @escaping (_ returnedData: ServerMeal?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Put attributes for a model instance and persist it

#### Parameters

- **id**  (required) Model id
- **data**  (optional) An object of model property name/value pairs
    - see [**ServerMeal**](ServerMeal.md)
- **completionHandler** (required)
    - closure takes as arguments `ServerMeal?`, `Response?` and  `Error?`

#### Response
[`ServerMeal`](ServerMeal.md)

### Authentication

No authentication required


### Example

```swift

let id: String = "id_example" // Model id
let data: ServerMeal = ServerMeal() // An object of model property name/value pairs

ServerMealAPI.serverMealReplace(id: id, data: data) { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealReplace() finished with status code: \(status)")
    }
}
```


### **serverMealUpdate**  {#serverMealUpdate}
---
```swift
public static func serverMealUpdate(id: String, data: ServerMeal? = nil, completionHandler: @escaping (_ returnedData: ServerMeal?, _ response: Response?, _ error: Error?) -> Void) -> Void
```

>Patch attributes for a model instance and persist it

#### Parameters

- **id**  (required) Model id
- **data**  (optional) An object of model property name/value pairs
    - see [**ServerMeal**](ServerMeal.md)
- **completionHandler** (required)
    - closure takes as arguments `ServerMeal?`, `Response?` and  `Error?`

#### Response
[`ServerMeal`](ServerMeal.md)

### Authentication

No authentication required


### Example

```swift

let id: String = "id_example" // Model id
let data: ServerMeal = ServerMeal() // An object of model property name/value pairs

ServerMealAPI.serverMealUpdate(id: id, data: data) { (returnedData, response, error) in
    guard error == nil else {
        print(error!)
        return
    }
    if let result = returnedData {
        print(result)
    }
    if let status = response?.statusCode {
        print("ServerMealAPI.serverMealUpdate() finished with status code: \(status)")
    }
}
```


[**Back to Top**](#top)
