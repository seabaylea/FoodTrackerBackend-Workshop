#!/bin/bash

# This script is used by Travis-CI to automatically release new versions of the SDK
# First, we check if the version specified in the .podspec does not already exist as a git tag
# If the version does not exist yet, we add a git tag for this new version and publish to Cocoapods
# You may add, delete, or modify any part of this file as needed for your SDK

set -ev
cd ~/Documents

# Replace all instances of YOUR_ORGANIZATION_NAME and YOUR_REPOSITORY with your Github organization and repository
# Generate the GITHUB_TOKEN: https://help.github.com/articles/creating-an-access-token-for-command-line-use/
# Copy the generated token to a Travis Environment Variable named GITHUB_TOKEN: https://docs.travis-ci.com/user/environment-variables/#Defining-Variables-in-Repository-Settings
git clone https://YOUR_ORGANIZATION_NAME:${GITHUB_TOKEN}@github.com/YOUR_ORGANIZATION_NAME/YOUR_REPOSITORY.git
cd YOUR_REPOSITORY
git remote rm origin
git remote add origin https://YOUR_ORGANIZATION_NAME:${GITHUB_TOKEN}@github.com/YOUR_ORGANIZATION_NAME/YOUR_REPOSITORY.git

version=$(grep -o 'version.*=.*[0-9]' .podspec | cut -f 2 -d "'")
git fetch --tags
if [[ ! "$(git tag)" =~ "${version}" ]]; then
	echo "Publishing new version ${version}";
	git tag $version;
	git push origin --tags;
	pod trunk push --allow-warnings;
fi
